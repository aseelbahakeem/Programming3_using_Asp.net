﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//new namesapse 
using System.Data.OleDb;


namespace StudentInfoSystem
{
    public partial class Form1 : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        public Form1()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider = Microsoft.Jet.OLEDB.4.0;data Source = C:\Users\Foton Bahakeem\Desktop\C#\student0.mdb; User Id = admin;Password =;";
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
            }
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            // Verify the Username and password whether they are present in database
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "select * from AdminInfo where Username='" +
           txt_Username.Text + "' and Password='" + txt_Password.Text + "'";

            //Read the record one by one in the table
            OleDbDataReader reader = command.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count++;
            }
            if (count == 1)
            {
                MessageBox.Show("Username and password is correct");
                connection.Close(); // close the connection before redirect
                connection.Dispose();
                this.Hide(); //hide the first form
                StudentInfo f2 = new StudentInfo();
                f2.ShowDialog();

            }
            else
            if (count > 1)
            {
                MessageBox.Show("Duplicate Username and password");
            }
            else
            {
                MessageBox.Show("Username and password is not correct");
            }
            connection.Close();
        }
    }
}
