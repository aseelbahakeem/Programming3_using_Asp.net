﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace StudentInfoSystem
{
    public partial class AddNewStudent : Form
    {
        private OleDbConnection connection = new OleDbConnection();

        public AddNewStudent()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider = Microsoft.Jet.OLEDB.4.0;data Source = C:\Users\Foton Bahakeem\Desktop\C#\student0.mdb; User Id = admin;Password =;";

        }

        private void AddNewStudent_Load(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "select * from StudentInfo";
                command.CommandText = query;
                OleDbDataReader reader = command.ExecuteReader();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == null || textBox3.Text == null || textBox1.Text == null || comboBox1.SelectedIndex == -1 || textBox4.Text == null)
            {
                MessageBox.Show("Please fill all the fields.");
            }
            else if (Double.Parse(textBox4.Text) < 0 || Double.Parse(textBox4.Text) > 5)
            {
                MessageBox.Show("The CPA must be between 0.0 and 5.0");
            }
            else
            {
                try
                {
                    connection.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = connection;
                    command.CommandText = "insert into StudentInfo (StudentID, Firstname, Lastname, CPA, Majoring) values('" + textBox1.Text + "', '" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + comboBox1.Text + "')";
                    command.ExecuteNonQuery();
                    MessageBox.Show("Data Added Successfully");
                    connection.Close();
                    connection.Dispose();
                    this.Hide(); //hide the third form
                    StudentInfo f2 = new StudentInfo();
                    f2.ShowDialog();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex);
                }
            }
        }

        private void txt_major_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_cpa_Click(object sender, EventArgs e)
        {

        }

        private void txt_lname_Click(object sender, EventArgs e)
        {

        }

        private void txt_fname_Click(object sender, EventArgs e)
        {

        }

        private void txt_ID_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            StudentInfo f2 = new StudentInfo();
            f2.Show();
            this.Hide();
        }
    }
}
