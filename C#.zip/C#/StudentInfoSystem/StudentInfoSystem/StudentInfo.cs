﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StudentInfoSystem
{

    public partial class StudentInfo : Form
    {
        
        private OleDbConnection connection = new OleDbConnection();



        public StudentInfo()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider = Microsoft.Jet.OLEDB.4.0;data Source = C:\Users\Foton Bahakeem\Desktop\C#\student0.mdb; User Id = admin;Password =;";

        }

        private void StudentInfo_Load(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "select * from StudentInfo";
                command.CommandText = query;
                OleDbDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    listBox1.Items.Add(reader["Firstname"].ToString());
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {

                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "select * from StudentInfo where Firstname='" +
               listBox1.Text + " '";
                command.CommandText = query;
                OleDbDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    textBox1.Text = reader["StudentID"].ToString();
                    textBox2.Text = reader["Firstname"].ToString();
                    textBox5.Text = reader["Lastname"].ToString();
                    textBox3.Text = reader["CPA"].ToString();
                    textBox4.Text = reader["Majoring"].ToString();
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
            }

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1 || textBox2.Text == null || textBox5.Text == null || textBox1.Text == null || textBox4.Text == null || textBox3.Text == null)
            {
                MessageBox.Show("Please choose a student from the database to update their information.");
            }
            else if (Double.Parse(textBox3.Text) < 0 || Double.Parse(textBox3.Text) > 5)
            {
                MessageBox.Show("The CPA must be between 1.0 and 5.0");
            }
            else
            {
                string message = "Do you want to save the content of this record ? ";
                string title = "Save Record";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, title, buttons);
                if (result == DialogResult.Yes)
                {
                    try
                    {

                        connection.Open();
                        OleDbCommand command = new OleDbCommand();
                        command.Connection = connection;
                        string query = "update StudentInfo" +
                            " set Firstname = '" + textBox2.Text + "', Lastname = '" + textBox5.Text + "' , CPA = '" + Convert.ToDouble(textBox3.Text) + 
                            "', Majoring = '" + textBox4.Text + "'where StudentID = '" + textBox1.Text + "'";

                        command.CommandText = query;
                        command.ExecuteNonQuery();
                        MessageBox.Show("Data Edit Successfully");
                        this.Hide();
                        StudentInfo f2 = new StudentInfo();
                        f2.ShowDialog();
                        connection.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error " + ex);
                    }
                }
                else
                {
                    // Do something else
                    MessageBox.Show("Edited data is not Saved");
                }

            }

        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1 || textBox2.Text == null || textBox5.Text == null || textBox1.Text == null || textBox4.Text == null || textBox3.Text == null)
            {
                MessageBox.Show("Please choose a student from the database to delete their information.");
            }
            else
            {
                string message = "Do you want to delete the content of this record ? ";
                string title = "Delete Record";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, title, buttons);
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        connection.Open();
                        OleDbCommand command = new OleDbCommand();
                        command.Connection = connection;


                        string query = "delete from StudentInfo where StudentID = '" + textBox1.Text + "'";
                        // MessageBox.Show(query);
                        command.CommandText = query;
                        command.ExecuteNonQuery();
                        MessageBox.Show("Data deleted Successfully");
                        this.Hide();
                        StudentInfo f2 = new StudentInfo();
                        f2.ShowDialog();
                        connection.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error " + ex);
                    }
                }
                else
                {
                    // Do something else
                    MessageBox.Show("No Data is removed");
                }
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            AddNewStudent add = new AddNewStudent();
            add.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for using the student management system.");
            Application.Exit();

        }

        private void txt_ID_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for using the student management system.");
            Application.Exit();
        }
    }
    }






